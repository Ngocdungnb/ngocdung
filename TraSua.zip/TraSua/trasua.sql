-- phpMyAdmin SQL Dump
-- version 4.7.9
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 01, 2018 at 05:17 PM
-- Server version: 10.1.31-MariaDB
-- PHP Version: 7.2.3

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `trasua`
--

-- --------------------------------------------------------

--
-- Table structure for table `cart`
--

CREATE TABLE `cart` (
  `id` int(11) NOT NULL,
  `idsp` int(11) NOT NULL,
  `qty` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `sanpham`
--

CREATE TABLE `sanpham` (
  `id` int(11) NOT NULL,
  `masp` text NOT NULL,
  `tensp` text NOT NULL,
  `details` text NOT NULL,
  `curren` float NOT NULL,
  `image` text NOT NULL,
  `sales` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `sanpham`
--

INSERT INTO `sanpham` (`id`, `masp`, `tensp`, `details`, `curren`, `image`, `sales`) VALUES
(1, 'TS1', 'TrÃ  sá»¯a Ã´ long', 'trÃ  sá»¯a ', 5, '6.jpg', 0),
(2, 'TS2', 'TrÃ  sá»¯a Ã´ ', 'trÃ  sá»¯a ', 5, '7.jpg', 10),
(5, 'TS1', 'TrÃ  sá»¯a Ã´ ', 'trÃ  sá»¯a ', 5, '1.jpg', 0),
(7, 'ts2', 'TrÃ  Sá»¯a ÄÃ o', 'TrÃ  Sá»¯a', 3, '15-honey-300x300.jpg', 0),
(8, 'TS2', 'Tra Sá»¯a Báº¡c HÃ ', 'aa', 5, '8.jpg', 0),
(9, 'TS1', 'Há»“ng TrÃ  Sá»¯a', '', 5, '4.jpg', 0),
(10, 'TS1', 'TrÃ  Ã” Long', '', 5, '123.jpg', 0),
(11, 'TS2', 'TrÃ  TrÃ¢n ChÃ¢u', '', 3, '5.jpg', 0);

-- --------------------------------------------------------

--
-- Table structure for table `slidebar`
--

CREATE TABLE `slidebar` (
  `id` int(11) NOT NULL,
  `img` varchar(15) NOT NULL,
  `details` text NOT NULL,
  `des` text NOT NULL,
  `active` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `slidebar`
--

INSERT INTO `slidebar` (`id`, `img`, `details`, `des`, `active`) VALUES
(1, '1.png', 'machiduca123', 'Feed Tea123', 1),
(4, '2.png', 'aaadasdasdasd', 'Blue Tea', 1),
(5, '3.png', 'asdasdasdasdasdasd', 'Tocotoco', 1);

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `id` int(11) NOT NULL,
  `username` varchar(20) NOT NULL,
  `password` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`id`, `username`, `password`) VALUES
(1, 'admin', '123456');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `cart`
--
ALTER TABLE `cart`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `sanpham`
--
ALTER TABLE `sanpham`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `slidebar`
--
ALTER TABLE `slidebar`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `cart`
--
ALTER TABLE `cart`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `sanpham`
--
ALTER TABLE `sanpham`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `slidebar`
--
ALTER TABLE `slidebar`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
