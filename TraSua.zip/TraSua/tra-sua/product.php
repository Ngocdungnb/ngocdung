<div class="clearfix"></div>
<div class="hom-slider">
    <div class="container">
        <div id="sequence">
            <div class="sequence-prev"><i class="fa fa-angle-left"></i></div>
            <div class="sequence-next"><i class="fa fa-angle-right"></i></div>
            <ul class="sequence-canvas">
                <?php while($rowslb = mysqli_fetch_array($checkslider)): ?>
                <li>
                    <div class="flat-caption caption2 formLeft delay400 text-center">
                        <h1><?php echo $rowslb['des'];?></h1>
                    </div>
                    <div class="flat-caption caption3 formLeft delay500 text-center">
                        <p><?php echo $rowslb['details'];?></p>
                    </div>
                    <div class="flat-button caption4 formLeft delay600 text-center"><a class="more" href="#">More Details</a></div>
                    <div class="flat-image formBottom delay200" data-duration="5" data-bottom="true"><img src="images/<?php echo $rowslb['img'];?>" alt="" style="width: 400px; height: 250px;"></div>
                </li>
                <?php endwhile; ?>
            </ul>
        </div>
    </div>
</div>
<div class="clearfix"></div>
<div class="container_fullwidth">
    <div class="container">
        <div class="hot-products">
            <h3 class="title"><strong>Hot</strong> Products</h3>
            <div class="control"><a id="prev_hot" class="prev" href="#">&lt;</a><a id="next_hot" class="next" href="#">&gt;</a></div>
            <ul id="hot">
                <li>
                    <div class="row">
                        <?php while($rowts1 = mysqli_fetch_array($checkts1)): ?>
                            <div class="col-md-3 col-sm-6">
                                <div class="products">
                                    <?php
                                    if($rowts1['sales']>0){
                                        echo '<div class="offer">'.'-'.$rowts1['sales'].'%'.'</div>';
                                    }
                                    ?>
                                    <div class="thumbnail"><a href="index.php?page=details&id=<?php echo $rowts1['id']?>"><img src="img/<?php echo $rowts1['image']; ?>" alt="Product Name" style="width: 180px;; height: 200px;;"></a></div>
                                    <div class="productname"><?php echo $rowts1['tensp']; ?></div>
                                    <h4 class="price">$<?php echo round(($rowts1['curren']-$rowts1['curren']*$rowts1['sales']/100),2); ?></h4>
                                    <div class="button_group"><button class="button add-cart" type="submit" name="add" value="<?php echo $rowts1['id']; ?>">Add To Cart</button><button class="button compare" type="button"><i class="fa fa-exchange"></i></button><button class="button wishlist" type="button"><i class="fa fa-heart-o"></i></button></div>
                                </div>
                            </div>
                        <?php endwhile; ?>
                    </div>
                </li>
                <li>
                    <div class="row">
                        <?php while($rowts1x = mysqli_fetch_array($checkts1x)): ?>
                            <div class="col-md-3 col-sm-6">
                                <div class="products">
                                    <?php
                                    if($rowts1x['sales']>0){
                                        echo '<div class="offer">'.'-'.$rowts1x['sales'].'%'.'</div>';
                                    }
                                    ?>
                                    <div class="thumbnail"><a href="index.php?page=details&id=<?php echo $rowts1x['id']?>"><img src="img/<?php echo $rowts1x['image']; ?>" alt="Product Name" style="width: 180px;; height: 200px;;"></a></div>
                                    <div class="productname"><?php echo $rowts1x['tensp']; ?></div>
                                    <h4 class="price">$<?php echo round(($rowts1x['curren']-$rowts1x['curren']*$rowts1x['sales']/100),2); ?></h4>
                                    <div class="button_group"><button class="button add-cart" type="submit" name="add" value="<?php echo $rowts1x['id']; ?>">Add To Cart</button><button class="button compare" type="button"><i class="fa fa-exchange"></i></button><button class="button wishlist" type="button"><i class="fa fa-heart-o"></i></button></div>
                                </div>
                            </div>
                        <?php endwhile; ?>
                    </div>
                </li>
            </ul>
        </div>
        <div class="clearfix"></div>
        <div class="featured-products">
            <h3 class="title"><strong>Featured </strong> Products</h3>
            <div class="control"><a id="prev_featured" class="prev" href="#">&lt;</a><a id="next_featured" class="next" href="#">&gt;</a></div>
            <ul id="featured">
                <li>
                    <div class="row">
                        <?php while($rowts2 = mysqli_fetch_array($checkts2)): ?>
                            <div class="col-md-3 col-sm-6">
                                <div class="products">
                                    <?php
                                    if($rowts2['sales']>0){
                                        echo '<div class="offer">'.'-'.$rowts2['sales'].'%'.'</div>';
                                    }
                                    ?>
                                    <div class="thumbnail"><a href="index.php?page=details&id=<?php echo $rowts2['id']?>"><img src="img/<?php echo $rowts2['image']; ?>" alt="Product Name" style="width: 180px;; height: 200px;;"></a></div>
                                    <div class="productname"><?php echo $rowts2['tensp']; ?></div>
                                    <h4 class="price">$<?php echo round(($rowts2['curren']-$rowts2['curren']*$rowts2['sales']/100),2); ?></h4>
                                    <div class="button_group"><button class="button add-cart" type="submit" name="add" value="<?php echo $rowts2['id']; ?>">Add To Cart</button><button class="button compare" type="button"><i class="fa fa-exchange"></i></button><button class="button wishlist" type="button"><i class="fa fa-heart-o"></i></button></div>
                                </div>
                            </div>
                        <?php endwhile; ?>
                    </div>
                </li>
                <li>
                    <div class="row">
                        <?php while($rowts2x = mysqli_fetch_array($checkts2x)): ?>
                            <div class="col-md-3 col-sm-6">
                                <div class="products">
                                    <?php
                                    if($rowts2x['sales']>0){
                                        echo '<div class="offer">'.'-'.$rowts2x['sales'].'%'.'</div>';
                                    }
                                    ?>
                                    <div class="thumbnail"><a href="index.php?page=details&id=<?php echo $rowts2x['id']?>"><img src="img/<?php echo $rowts2x['image']; ?>" alt="Product Name" style="width: 180px;; height: 200px;;"></a></div>
                                    <div class="productname"><?php echo $rowts2x['tensp']; ?></div>
                                    <h4 class="price">$<?php echo round(($rowts2x['curren']-$rowts2x['curren']*$rowts2x['sales']/100),2); ?></h4>
                                    <div class="button_group"><button class="button add-cart" type="submit" name="add" value="<?php echo $rowts2x['id']; ?>">Add To Cart</button><button class="button compare" type="button"><i class="fa fa-exchange"></i></button><button class="button wishlist" type="button"><i class="fa fa-heart-o"></i></button></div>
                                </div>
                            </div>
                        <?php endwhile; ?>
                    </div>
                </li>
            </ul>
        </div>
        <div class="clearfix"></div>
    </div>
</div>