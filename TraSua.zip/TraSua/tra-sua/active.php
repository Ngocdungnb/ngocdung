<?php
require "connect/connect.php";
$checkts1 = $conn->query("SELECT * FROM sanpham WHERE masp = 'TS1' ORDER BY curren DESC LIMIT 0,4");
$checkts1x = $conn->query("SELECT * FROM sanpham WHERE masp = 'TS1' ORDER BY curren DESC LIMIT 4,4");
$checkts2 = $conn->query("SELECT * FROM sanpham WHERE masp = 'TS2' ORDER BY curren DESC LIMIT 0,4");
$checkts2x = $conn->query("SELECT * FROM sanpham WHERE masp = 'TS2' ORDER BY curren DESC LIMIT 4,4");
$checkslider = $conn->query("SELECT * FROM slidebar WHERE `active`='1'");
if(isset($_POST['add'])){
    $id = $_POST['add'];
    $qty = 1;
    $check = $conn->query("SELECT * FROM cart WHERE `idsp` = '$id'");
    if(mysqli_num_rows($check)>0){
        $row = mysqli_fetch_array($check);
        $qty = $row['qty'] + 1;
        $conn->query("UPDATE cart SET `qty`='$qty' WHERE `idsp`='$id' ");
    }else{
        $conn->query("INSERT INTO cart(`idsp`,`qty`) VALUES ('$id','$qty')");
    }
}
$checkcart = $conn->query("SELECT * FROM cart");
$checkcartx = $conn->query("SELECT * FROM cart");
$sum = 0;
while($rowsum = mysqli_fetch_array($checkcartx)):
    $sum += $rowsum['qty'];
endwhile;

if(isset($_POST['login'])){
    $username = $_POST['username'];
    $password = $_POST['password'];

    $login = $conn->query("SELECT * FROM user WHERE `username`='$username' and `password`='$password'");
    if(mysqli_num_rows($login)>0){
        header("location: admin/admin.php");
    }else{
        echo "<script type='text/javascript'>alert('Bạn nhập sai tài khoản hoặc mật khẩu!');</script>";
    }

}
if(isset($_POST['add-details'])){
    $id = $_POST['add-details'];
    $qty = $_POST['qty-details'];
    if($qty<=0){
        echo "<script type='text/javascript'>alert('Số lượng phải lớn hơn 0!');</script>";
    }else{
        $check = $conn->query("SELECT * FROM cart WHERE `idsp` = '$id'");
        if(mysqli_num_rows($check)>0){
            $row = mysqli_fetch_array($check);
            $qty += $row['qty'];
            $conn->query("UPDATE cart SET `qty`='$qty' WHERE `idsp`='$id' ");
        }else{
            $conn->query("INSERT INTO cart(`idsp`,`qty`) VALUES ('$id','$qty')");
        }
    }
}

?>