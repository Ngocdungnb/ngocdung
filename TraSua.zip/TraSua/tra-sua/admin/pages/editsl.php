<?php
include "../connect/connect.php";
    $checkedn = '';
    $checkedy = '';
    $idsp = $_GET['idsl'];
    $editsp =  $conn->query("SELECT * FROM slidebar WHERE `id`='$idsp'");
    $rowed = mysqli_fetch_array($editsp);
    if($rowed['active']==0){
        $checkedn = 'checked';
    }elseif($rowed['active']==1){
        $checkedy = 'checked';
    }
    if(isset($_POST['editsl'])){
        $img = $_POST['img'];
        $des = $_POST['des'];
        $detail = $_POST['details'];
        $active = $_POST['active'];
        if($img==''){
            $img = $rowed['img'];
        }
        $update = $conn->query("UPDATE slidebar SET `img`='$img',`des`='$des',`details`='$detail',`active`='$active' WHERE `id`='$idsp'");
        if(isset($update)){
            header("location:admin.php?page=slider#danhsachtin-tab ");
        }
    }
?>

<div id="themmoitin" class="tabcontent" style="margin: 20px 30px; width: 900px; height: 650px;">
    <form method="post">
        <div class="themform">
            <span>Hình ảnh: </span>
            <img src="../images/<?php echo $rowed['img']; ?>" style="height: 150px; width: 180px; margin: 10px;">
            <input type="file"  name="img" />
        </div>
        <div class="themform">
            <span>Sologan: </span>
            <input type="text" placeholder="Sologan" name="des"  maxlength="50" value="<?php echo $rowed['des'];?>" required />
        </div>
        <div class="themform">
            <span>Active: </span>
            <input type="radio" name="active" style="height: 20px; width: 20px;" value="1" <?php echo $checkedy;?> />
            <b>Yes</b>
            <input type="radio" name="active" style="height: 20px; width: 20px;" value="0" <?php echo $checkedn;?>/>
            <b>No</b>
        </div>
        <div class="themformnews">
            <span>Mô tả: </span>
            <textarea name="details" placeholder="Nội dung..."><?php echo $rowed['details'] ?></textarea>
        </div>
        <div class="buttonthem">
            <input type="reset" value="Cancel" />
            <input type="submit" value="OK"  name="editsl" />
        </div>
    </form>
</div>