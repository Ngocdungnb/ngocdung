<?php
include "../connect/connect.php";
if(isset($_POST['themformsl'])){
    $img = $_POST['img'];
    $des = $_POST['des'];
    $detail = $_POST['details'];

    $check = $conn->query("INSERT INTO slidebar(`img`,`des`,`details`) VALUES ('$img','$des','$detail')");
    if(isset($check)){
        echo "<script type='text/javascript'>alert('Thêm sản phẩm thành công!');</script>";
    }
}
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <title>Untitled Document</title>
</head>

<body>
<ul id="tabsmenu" class="tabsmenu">
    <li class="active"><a href="#themmoitin">Thêm mới slider</a></li>
    <li><a href="#danhsachtin">Danh sách slider</a></li>
</ul>
<div id="themmoitin" class="tabcontent">
    <form method="post">
        <div class="themform">
            <span>Hình ảnh: </span>
            <input type="file"  name="img"   required/>
        </div>
        <div class="themform">
        <span>Sologan: </span>
            <input type="text" placeholder="Sologan" name="des"  maxlength="50"/>
        </div>
        <div class="themformnews">
            <span>Mô tả: </span>
            <textarea name="details" placeholder="Nội dung..."></textarea>
        </div>
        <div class="buttonthem">
            <input type="reset" value="Cancel" />
            <input type="submit" value="OK"  name="themformsl" />
        </div>
    </form>
</div>
<div id="danhsachtin" class="tabcontent">
    <?php
    include "../connect/connect.php";
    if (!isset($_GET['trang'])) {
        $_GET['trang'] = 1;
    }
    $start = $_GET['trang'] - 1;
    $sotin = 4;
    $tiep = $start * $sotin;
    $count = mysqli_num_rows($conn->query("SELECT * FROM slidebar"));
    $trongtrang = ceil($count / $sotin);
    $laybdiem = $conn->query("SELECT * FROM slidebar ORDER BY id ASC LIMIT $tiep,$sotin");
    $num = mysqli_num_rows($laybdiem);
    if ($num > 0){
    ?>
    <div class="post-body2">
        <br/>
        <h1 align="center"><?php echo 'DANH SÁCH SẢN PHẨM'; ?></h1>
        <table cellpadding="0" cellspacing="0" style="text-align: left;">
            <thead>
            <tr>
                <th width="50">STT</th>
                <th>Tên slider</th>
                <th>Mô tả</th>
                <th>Ảnh</th>
                <th>Active</th>
                <th>Chức năng</th>
            </tr>
            </thead>
            <tbody>
            <?php $k = 0;
            while ($laydiem = mysqli_fetch_array($laybdiem) and $k < $num): ?>
                <tr>
                    <td><?php echo $k + 1 ?></td>
                    <td><?php echo $laydiem['des'] ?></td>
                    <td width="150"><?php echo $laydiem['details'] ?></td>
                    <td><img src="../images/<?php echo $laydiem['img'] ?>" alt="Tea" style="height: 80px; width: 120px;"/></td>
                    <td><?php echo $laydiem['active'] ?></td>
                    <td>
                        <?php echo "<a href='admin.php?page=editsl&idsl=$laydiem[0]'>Sửa</a>"; ?> |
                        <?php echo "<a onclick=\" return confirm ('Bạn chắc chắn chưa?')\" href='admin.php?page=del&idsl=$laydiem[0]'>Xóa</a>";?>
                    </td>
                </tr>
                <?php $k++; endwhile; ?>
            </tbody>
        </table>
        <br/><span style="margin: 10px;">
                     <?php
                     for ($i = 1; $i <= $trongtrang; $i++) {
                         if ($i == $_GET['trang']) {
                             echo ' Trang ' . $i;
                         } else {
                             echo ' ' . '<a href="admin.php?trang='.$i.'#danhsachtin-tab">Trang ' . $i . '</a>';
                         }
                     }
                     }
                     ?>
                </span>
</div>
</body>
</html>