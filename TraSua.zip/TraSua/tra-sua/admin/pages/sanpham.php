<?php
    include "../connect/connect.php";
    if(isset($_POST['themform'])){
        $masp = $_POST['masp'];
        $tensp = $_POST['tensp'];
        $curren = $_POST['curren'];
        $img = $_POST['img'];
        $sale = $_POST['sales'];
        $detail = $_POST['details'];

        $check = $conn->query("INSERT INTO sanpham(`masp`,`tensp`,`curren`,`image`,`sales`,`details`) VALUES ('$masp','$tensp','$curren','$img','$sale','$detail')");
        if(isset($check)){
            echo "<script type='text/javascript'>alert('Thêm sản phẩm thành công!');</script>";
        }
    }
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
</head>

<body>
 <ul id="tabsmenu" class="tabsmenu">
        <li class="active"><a href="#themmoitin">Thêm mới sản phẩm</a></li>
        <li><a href="#danhsachtin">Danh sách sản phẩm</a></li>
    </ul>
    <div id="themmoitin" class="tabcontent">
        	<form method="post">
            <div class="themform">
                <span>Mã sản phẩm: </span>
                <input type="text" placeholder="Mã sản phẩm" name="masp"  maxlength="50" required/>
            </div>
            <div class="themform">
                <span>Tên sản phẩm: </span>
                <input type="text" placeholder="Tên sản phẩm" name="tensp"  maxlength="50" required/>
            </div>
            <div class="themform">
                <span>Giá thành: </span>
                <input type="text" placeholder="Giá thành" name="curren"  maxlength="50" required/>
            </div>
            <div class="themform">
                <span>Hình ảnh: </span>
                <input type="file"  name="img"   required/>
            </div>
            <div class="themform">
                <span>Sales: </span>
                <input type="text" placeholder="Sales" name="sales"  maxlength="50"/>
            </div>
            <div class="themformnews">
                <span>Mô tả: </span>
                <textarea name="details" placeholder="Nội dung..."></textarea>
            </div>
            <div class="buttonthem">
                <input type="reset" value="Cancel" />
                <input type="submit" value="OK"  name="themform" />
            </div>
        </form>
    </div>
    <div id="danhsachtin" class="tabcontent">
        <?php
            include "../connect/connect.php";
            if (!isset($_GET['trang'])) {
                $_GET['trang'] = 1;
            }
            $start = $_GET['trang'] - 1;
            $sotin = 4;
            $tiep = $start * $sotin;
            $count = mysqli_num_rows($conn->query("SELECT * FROM sanpham"));
            $trongtrang = ceil($count / $sotin);
            $laybdiem = $conn->query("SELECT * FROM sanpham ORDER BY id ASC LIMIT $tiep,$sotin");
            $num = mysqli_num_rows($laybdiem);
            if ($num > 0){
            ?>
            <div class="post-body2">
                <br/>
                <h1 align="center"><?php echo 'DANH SÁCH SẢN PHẨM'; ?></h1>
                <table cellpadding="0" cellspacing="0" style="text-align: left;">
                    <thead>
                    <tr>
                        <th width="50">STT</th>
                        <th>Tên sản phẩm</th>
                        <th>Mô tả</th>
                        <th>Giá thành($)</th>
                        <th>Ảnh</th>
                        <th>Sales(%)</th>
                        <th>Chức năng</th>
                    </tr>
                    </thead>
                    <tbody>
                    <?php $k = 0;
                    while ($laydiem = mysqli_fetch_array($laybdiem) and $k < $num): ?>
                        <tr>
                            <td><?php echo $k + 1 ?></td>
                            <td><?php echo $laydiem['tensp'] ?></td>
                            <td width="150"><?php echo $laydiem['details'] ?></td>
                            <td><?php echo $laydiem['curren'] ?></td>
                            <td><img src="../img/<?php echo $laydiem['image'] ?>" alt="Tea" style="height: 100px; width: 80px;"/></td>
                            <td><?php echo $laydiem['sales'] ?></td>
                            <td>
                                <?php echo "<a href='admin.php?page=edit&idsp=$laydiem[0]'>Sửa</a>"; ?> |
                                <?php echo "<a onclick=\" return confirm ('Bạn chắc chắn chưa?')\" href='admin.php?page=del&idsp=$laydiem[0]'>Xóa</a>";?>
                            </td>
                        </tr>
                        <?php $k++; endwhile; ?>
                    </tbody>
                </table>
                <br/><span style="margin: 10px;">
                     <?php
                     for ($i = 1; $i <= $trongtrang; $i++) {
                         if ($i == $_GET['trang']) {
                             echo ' Trang ' . $i;
                         } else {
                             echo ' ' . '<a href="admin.php?trang='.$i.'#danhsachtin-tab">Trang ' . $i . '</a>';
                         }
                     }
             }
        ?>
                </span>
    </div>
</body>
</html>