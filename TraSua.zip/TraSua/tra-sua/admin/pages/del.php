<?php
    include "../connect/connect.php";
    if(isset($_GET['idsp'])){
        $idsp = $_GET['idsp'];
        $conn->query("DELETE FROM sanpham WHERE `id`='$idsp'");
        header("location: admin.php#danhsachtin-tab");
    }
    if(isset($_GET['idsl'])){
        $idsl = $_GET['idsl'];
        $conn->query("DELETE FROM slidebar WHERE `id`='$idsl'");
        header("location: admin.php?page=slider#danhsachtin-tab");
    }
?>