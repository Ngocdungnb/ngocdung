<?php
include "../connect/connect.php";
    $idsp = $_GET['idsp'];
    $editsp =  $conn->query("SELECT * FROM sanpham WHERE `id`='$idsp'");
    $rowed = mysqli_fetch_array($editsp);
    if(isset($_POST['editsp'])){
        $masp = $_POST['masp'];
        $tensp = $_POST['tensp'];
        $curren = $_POST['curren'];
        $img = $_POST['img'];
        $sale = $_POST['sales'];
        $detail = $_POST['details'];
        if($img==''){
            $img = $rowed['image'];
        }

        $update = $conn->query("UPDATE sanpham SET `masp`='$masp',`tensp`='$tensp',`curren`='$curren',`image`='$img',`sales`='$sale',`details`='$detail' WHERE `id`='$idsp'");
    if(isset($update)){
            header("location: admin.php#danhsachtin-tab");
         }
    }
?>
<div id="themmoitin" class="tabcontent" style="margin: 20px 30px; width: 900px; height: 650px;">
    <form method="post">
        <div class="themform">
            <span>Mã sản phẩm: </span>
            <input type="text" placeholder="Mã sản phẩm" name="masp"  maxlength="50" value="<?php echo $rowed['masp'] ?>" required/>
            <span>Giá thành: </span>
            <input type="text" placeholder="Giá thành" name="curren"  maxlength="50" value="<?php echo $rowed['curren'] ?>" required/>
        </div>
        <div class="themform">
            <span>Tên sản phẩm: </span>
            <input type="text" placeholder="Tên sản phẩm" name="tensp"  maxlength="50" value="<?php echo $rowed['tensp'] ?>" required/>
            <span>Sales: </span>
            <input type="text" placeholder="Sales" name="sales" value="<?php echo $rowed['sales'] ?>"  maxlength="50"/>
        </div>
        <div class="themform">
            <span>Hình ảnh: </span>
            <img src="../img/<?php echo $rowed['image'] ?>" style="height: 150px; width: 150px; margin: 10px;">
            <input type="file"  name="img">
        </div>
        <div class="themformnews">
            <span>Mô tả: </span>
            <textarea name="details" placeholder="Nội dung..."><?php echo $rowed['details'] ?></textarea>
        </div>
        <div class="buttonthem">
            <input type="reset" value="Cancel" />
            <input type="submit" value="OK"  name="editsp" />
        </div>
    </form>
</div>
