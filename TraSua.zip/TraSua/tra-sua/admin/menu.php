<?php
if(!isset($_GET["page"])){
    require_once("pages/sanpham.php");
}
if(isset($_GET["page"])){
    $page = $_GET["page"];
    switch($page){
        case "slider":
            require_once("pages/slider.php");
            break;
        case "edit":
            require_once("pages/edit.php");
            break;
        case "editsl":
            require_once("pages/editsl.php");
            break;
        case "del":
            require_once("pages/del.php");
            break;
        default:
            require_once("admin.php");
    }
}
?>