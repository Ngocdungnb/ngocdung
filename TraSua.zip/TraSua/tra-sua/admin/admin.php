<p align="right">Welcome Admin | <a href="../index.php">Đăng xuất</a></p>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Admin</title>
<link rel="stylesheet" type="text/css" href="style.css" />
<link href='http://fonts.googleapis.com/css?family=Belgrano' rel='stylesheet' type='text/css'>
<!-- jQuery file -->
<script src="js/jquery.min.js"></script>
<script src="js/jquery.tabify.js" type="text/javascript" charset="utf-8"></script>
<script type="text/javascript">
var $ = jQuery.noConflict();
$(function() {
$('#tabsmenu').tabify();
$(".toggle_container").hide();
$(".trigger").click(function(){
	$(this).toggleClass("active").next().slideToggle("slow");
	return false;
});
});
</script>
</head>
<body>
<div id="panelwrap">
  <div class="header">
  	<img src="images/banner1.jpg" width="1000" height="200" />
    <div class="menu">
        <ul>
            <li><a href="admin.php">Quản lý sản phẩm</a></li>
            <li><a href="admin.php?page=slider" class="parent"><span>Quản lý slider</span></a></li>
        </ul>
      </div> 
  </div>          
    <div class="center_content">
    <div id="right_wrap" style="margin-left: 10px;">
    <?php require("menu.php")?>
     </div>
    </div>
    <div class="clear"></div>
    </div>
    <div class="footer">
</div>
</div>	
</body>
</html>