<?php
require "active.php";
?>
<!DOCTYPE html>
<html>
   <head>
      <meta http-equiv="Content-Type" content="text/html;charset=utf-8"/>
      <meta name="description" content="">
      <meta name="viewport" content="width=device-width, initial-scale=1.0">
      <link rel="shortcut icon" href="images/favicon.png">
      <title>Bopbabop</title>
      <link href="css/bootstrap.css" rel="stylesheet">
      <link href='http://fonts.googleapis.com/css?family=Roboto:400,300,300italic,400italic,500,700,500italic,100italic,100' rel='stylesheet' type='text/css'>
      <link href="css/font-awesome.min.css" rel="stylesheet">
      <link rel="stylesheet" href="css/flexslider.css" type="text/css" media="screen"/>
      <link href="css/sequence-looptheme.css" rel="stylesheet" media="all"/>
      <link href="css/style.css" rel="stylesheet">
   </head>
   <form method="post">
      <body id="home">
         <div class="wrapper">
            <div class="header">
               <div class="container">
                  <div class="row">
                     <div class="col-md-2 col-sm-2">
                        <div class="logo"><a href="index.php"><img src="images/logo.png" alt="Bopbabop" style="width: 150px; height: 70px;"></a></div>
                     </div>
                     <div class="col-md-10 col-sm-10">
                        <div class="header_top">
                           <div class="row">
                              <div class="col-md-3">
                                 </ul>
                              </div>
                              <div class="col-md-6">
                                 <ul class="topmenu">
                                    <li><a href="#">About Us</a></li>
                                    <li><a href="#">News</a></li>
                                    <li><a href="#">Service</a></li>
                                    <li><a href="#">Recruiment</a></li>
                                    <li><a href="#">Media</a></li>
                                    <li><a href="#">Support</a></li>
                                 </ul>
                              </div>
                              <div class="col-md-3">
                                 <ul class="usermenu">
                                    <li><a href="index.php?page=login" class="log">Login</a></li>
                                    <li><a href="index.php?page=regis" class="reg">Register</a></li>
                                 </ul>
                              </div>
                           </div>
                        </div>
                        <div class="clearfix"></div>
                        <div class="header_bottom">
                           <ul class="option">
                              <li id="search" class="search">
                                    <input placeholder="Enter your search term..." type="text" value="" name="search" style="height: 32px; margin: 0px 5px;">
                                    <input class="search-submit" type="submit" value="">
                              </li>
                              <li class="option-cart">
                                 <a href="#" class="cart-icon">cart <span class="cart_no"><?php echo $sum; ?></span></a>
                                 <ul class="option-cart-item">
                                     <?php
                                     $total = 0;
                                     while($rowcart = mysqli_fetch_array($checkcart)):
                                         $id = $rowcart['idsp'];
                                         $thongso = $conn->query("SELECT * FROM sanpham WHERE `id`='$id'");
                                         $rowts = mysqli_fetch_array($thongso);
                                         ?>
                                    <li>
                                       <div class="cart-item">
                                          <div class="image"><img src="img/<?php echo $rowts['image']; ?>" alt="" style="width: 120px; height: 150px;"></div>
                                          <div class="item-description">
                                             <p class="name"></p>
                                             <p>Size: <span class="light-red">One size</span><br>Quantity: <span class="light-red"><?php echo $rowcart['qty']?></span></p>
                                          </div>
                                          <div class="right">
                                              <a href="remove.php?id=<?php echo $rowcart['idsp'];?>" class="remove"><img src="images/remove.png" alt="remove"></a>
                                             <p class="price">$ <?php echo round(($rowts['curren']-$rowts['curren']*$rowts['sales']/100),2)*$rowcart['qty'];?></p>
                                          </div>
                                       </div>
                                    </li>
                                     <?php
                                     $total += round(($rowts['curren']-$rowts['curren']*$rowts['sales']/100),2)*$rowcart['qty'];
                                     endwhile;?>
                                    <li><span class="total">Total <strong>$<?php echo $total; ?></strong></span><button class="checkout" onClick="location.href='checkout.html'">CheckOut</button></li>
                                 </ul>
                              </li>
                           </ul>
                           <div class="navbar-header"><button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse"><span class="sr-only">Toggle navigation</span><span class="icon-bar"></span><span class="icon-bar"></span><span class="icon-bar"></span></button></div>
                           <div class="navbar-collapse collapse">
                              <ul class="nav navbar-nav">
                                 <li><a href="index.php">Home</a></li>
                                 <li><a href="#">gift</a></li>
                                 <li><a href="#">kids</a></li>
                                 <li><a href="#">blog</a></li>
                                 <li><a href="#">jewelry</a></li>
                                 <li><a href="#">contact us</a></li>
                              </ul>
                           </div>
                        </div>
                     </div>
                  </div>
               </div>
            </div>
            <?php
                if(!isset($_GET["page"])){
                    require_once("product.php");
                }
                if(isset($_GET["page"])){
                    $page = $_GET["page"];
                    switch($page){
                        case "details":
                            require_once("details.php");
                            break;
                        case "login":
                            require_once("checkout.php");
                            break;
                        case "regis":
                            require_once("checkout2.php");
                            break;
                        default:
                            require_once("index.php");
                    }
                }
            ?>
            </div>
            <div class="clearfix"></div>
            </div>
         </div>
         <!-- Bootstrap core JavaScript==================================================-->
        <script type="text/javascript" src="js/jquery-1.10.2.min.js"></script>
        <script type="text/javascript" src="js/jquery.easing.1.3.js"></script>
        <script type="text/javascript" src="js/bootstrap.min.js"></script>
        <script type="text/javascript" src="js/jquery.sequence-min.js"></script>
        <script type="text/javascript" src="js/jquery.carouFredSel-6.2.1-packed.js"></script>
        <script defer src="js/jquery.flexslider.js"></script>
        <script type="text/javascript" src="js/script.min.js" ></script>
      </body>
   </form>
</html>