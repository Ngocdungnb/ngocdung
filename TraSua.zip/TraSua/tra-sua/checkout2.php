<div class="clearfix">
</div>
<div class="container_fullwidth" style="height: 580px;">
<div class="container">
<div class="row">
<div class="col-md-9">
<div class="checkout-page">
<ol class="checkout-steps">
<li class="steps active">
    <div class="step-description">
        <form>
            <div class="row">
                <div class="col-md-6 col-sm-6">
                    <div class="your-details">
                        <h5>
                            Register
                        </h5>
                        <div class="form-row">
                            <label class="lebel-abs">
                                First Name
                                <strong class="red">
                                    *
                                </strong>
                            </label>
                            <input type="text" class="input namefild" name="">
                        </div>
                        <div class="form-row">
                            <label class="lebel-abs">
                                Last Name
                                <strong class="red">
                                    *
                                </strong>
                            </label>
                            <input type="text" class="input namefild" name="">
                        </div>
                        <div class="form-row">
                            <label class="lebel-abs">
                                Email
                                <strong class="red">
                                    *
                                </strong>
                            </label>
                            <input type="text" class="input namefild" name="">
                        </div>
                        <div class="form-row">
                            <label class="lebel-abs">
                                Telephone
                                <strong class="red">
                                    *
                                </strong>
                            </label>
                            <input type="text" class="input namefild" name="">
                        </div>
                        <div class="form-row">
                            <label class="lebel-abs">
                                Fax
                                <strong class="red">
                                    *
                                </strong>
                            </label>
                            <input type="text" class="input namefild" name="">
                        </div>
                        <div class="form-row">
                            <label class="lebel-abs">
                                Company
                                <strong class="red">
                                    *
                                </strong>
                            </label>
                            <input type="text" class="input namefild" name="">
                        </div>
                        <div class="pass-wrap">
                            <div class="form-row">
                                <label class="lebel-abs">
                                    Your Password
                                    <strong class="red">
                                        *
                                    </strong>
                                </label>
                                <input type="password" class="input namefild" name="">
                            </div>
                            <div class="form-row">
                                <label class="lebel-abs">
                                    Confird Your Password
                                    <strong class="red">
                                        *
                                    </strong>
                                </label>
                                <input type="password" class="input cpass" name="">
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-md-6 col-sm-6">
                    <div class="your-details">
                        <h5>
                            Your Address
                        </h5>
                        <div class="form-row">
                            <label class="lebel-abs">
                                Address 01
                                <strong class="red">
                                    *
                                </strong>
                            </label>
                            <input type="text" class="input namefild" name="">
                        </div>
                        <div class="form-row">
                            <label class="lebel-abs">
                                Address 02
                                <strong class="red">
                                    *
                                </strong>
                            </label>
                            <input type="text" class="input namefild" name="">
                        </div>
                        <div class="form-row">
                            <label class="lebel-abs">
                                City
                                <strong class="red">
                                    *
                                </strong>
                            </label>
                            <input type="text" class="input namefild" name="">
                        </div>
                        <div class="form-row">
                            <label class="lebel-abs">
                                Pass Code
                                <strong class="red">
                                    *
                                </strong>
                            </label>
                            <input type="text" class="input namefild" name="">
                        </div>
                        <div class="form-row">
                            <label class="lebel-abs">
                                Country
                                <strong class="red">
                                    *
                                </strong>
                            </label>
                            <input type="text" class="input namefild" name="">
                        </div>
                        <div class="form-row">
                            <label class="lebel-abs">
                                Region / State
                                <strong class="red">
                                    *
                                </strong>
                            </label>
                            <input type="text" class="input namefild" name="">
                        </div>
                        <p class="privacy">
                                <span class="input-radio">
                                  <input type="radio" name="user">
                                </span>
                                <span class="text">
                                  I have read and agree to the
                                  <a href="#" class="red">
                                      Privacy Policy
                                  </a>
                                </span>
                        </p>
                        <button>
                            Register
                        </button>
                    </div>
                </div>
            </div>
        </form>
    </div>
</li>
</ol>
</div>
</div>
</div>
<div class="clearfix">
</div>