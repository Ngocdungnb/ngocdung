<?php 
	$conn = mysqli_connect('localhost','root','','trasua');
	// mysql_select_db('qlhs',$conn);
	
?>