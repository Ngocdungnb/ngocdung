<?php
require "connect/connect.php";
$id = $_GET['id'];
$remove = $conn->query("DELETE FROM cart WHERE `idsp`='$id'");
header("location: index.php");

?>