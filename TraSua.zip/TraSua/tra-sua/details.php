<?php
 $id = $_GET{'id'};
 $details = $conn->query("SELECT * FROM sanpham WHERE `id`='$id'");
 $rowdt = mysqli_fetch_array($details);
 $masp = $rowdt['masp'];
 $find = $conn->query("SELECT * FROM sanpham  ORDER BY RAND() LIMIT 3");
?>
<div class="container_fullwidth">
<div class="container">
<div class="row">
<div class="col-md-9">
<div class="products-details">
    <div class="preview_image">
        <div class="preview-small">
            <img id="zoom_03" src="img/<?php echo $rowdt['image']; ?>" data-zoom-image="img/<?php echo $rowdt['image']; ?>" alt="" style="height: 340px;">
        </div>
    </div>
    <div class="products-description">
        <h5 class="name">
            <?php echo $rowdt['tensp']; ?>
        </h5>
        <p>
            <img alt="images/star.png" src="images/star.png">
            <a class="review_num" href="#">
                02 Review(s)
            </a>
        </p>
        <p>
            Availability:
                    <span class=" light-red">
                      In Stock
                    </span>
        </p>
        <p>
            <?php echo $rowdt['details']; ?>
        </p>
        <hr class="border">
        <div class="price">
            Price :
                    <span class="new_price">
                      <?php echo round(($rowdt['curren']-$rowdt['curren']*$rowdt['sales']/100),2);?>
                      <sup>
                          $
                      </sup>
                    </span>
        </div>
        <hr class="border">
        <div class="wided"></div>
            <div class="qty">
                Qty &nbsp;&nbsp;:
                <input type="number" name="qty-details" style="width: 70px;" value="1">
            </div>
            <div class="button_group">
                <button class="button" name="add-details" value="<?php echo $rowdt['id'];?>" type="submit">Add To Cart</button>
                <button class="button compare">
                    <i class="fa fa-exchange">
                    </i>
                </button>
                <button class="button favorite">
                    <i class="fa fa-heart-o">
                    </i>
                </button>
                <button class="button favorite">
                    <i class="fa fa-envelope-o">
                    </i>
                </button>
            </div>
        </div>
        <div class="clearfix">
        </div>
        <hr class="border">
        <img src="images/share.png" alt="" class="pull-right">
    </div>
</div>
<div class="col-md-3">
        <div class="special-deal leftbar">
            <h4 class="title">
                Special
                <strong>
                    Deals
                </strong>
            </h4>
            <?php while( $rowdtx = mysqli_fetch_array($find)): ?>
            <div class="special-item">
                <div class="product-image">
                    <a href="index.php?page=details&id=<?php echo $rowdtx['id']?>">
                        <img src="img/<?php echo $rowdtx['image'];?>" alt="" style="height: 70px; width: 100px;">
                    </a>
                </div>
                <div class="product-info">
                    <p>
                        <?php echo $rowdtx['tensp'];?>
                    </p>
                    <h5 class="price">
                        $<?php echo round(($rowdtx['curren']-$rowdtx['curren']*$rowdtx['sales']/100),2);?>
                    </h5>
                </div>
            </div>
            <?php endwhile;?>
        </div>
        <div class="clearfix">
        </div>
        <div class="get-newsletter leftbar">
            <h3 class="title">
                Get
                <strong>
                    newsletter
                </strong>
            </h3>
            <p>
                Casio G Shock Digital Dial Black.
            </p>
            <form>
                <input class="email" type="text" name="" placeholder="Your Email...">
                <input class="submit" type="submit" value="Submit">
            </form>
        </div>
        <div class="clearfix">
        </div>
    </div>
</div>
<div class="clearfix">
</div>
<div class="tab-box">
<div id="tabnav">
    <ul>
        <li>
            <a href="#Descraption">
                DESCRIPTION
            </a>
        </li>
        <li>
            <a href="#Reviews">
                REVIEW
            </a>
        </li>
    </ul>
</div>
<div class="tab-content-wrap">
    <div class="tab-content" id="Descraption">
        <?php echo $rowdt['details']; ?>
    </div>
    <div class="tab-content" id="Reviews">
        <form>
            <table>
                <thead>
                <tr>
                    <th>
                        &nbsp;
                    </th>
                    <th>
                        1 star
                    </th>
                    <th>
                        2 stars
                    </th>
                    <th>
                        3 stars
                    </th>
                    <th>
                        4 stars
                    </th>
                    <th>
                        5 stars
                    </th>
                </tr>
                </thead>
                <tbody>
                <tr>
                    <td>
                        Quality
                    </td>
                    <td>
                        <input type="radio" name="quality" value="Blue"/>
                    </td>
                    <td>
                        <input type="radio" name="quality" value="">
                    </td>
                    <td>
                        <input type="radio" name="quality" value="">
                    </td>
                    <td>
                        <input type="radio" name="quality" value="">
                    </td>
                    <td>
                        <input type="radio" name="quality" value="">
                    </td>
                </tr>
                <tr>
                    <td>
                        Price
                    </td>
                    <td>
                        <input type="radio" name="price" value="">
                    </td>
                    <td>
                        <input type="radio" name="price" value="">
                    </td>
                    <td>
                        <input type="radio" name="price" value="">
                    </td>
                    <td>
                        <input type="radio" name="price" value="">
                    </td>
                    <td>
                        <input type="radio" name="price" value="">
                    </td>
                </tr>
                <tr>
                    <td>
                        Value
                    </td>
                    <td>
                        <input type="radio" name="value" value="">
                    </td>
                    <td>
                        <input type="radio" name="value" value="">
                    </td>
                    <td>
                        <input type="radio" name="value" value="">
                    </td>
                    <td>
                        <input type="radio" name="value" value="">
                    </td>
                    <td>
                        <input type="radio" name="value" value="">
                    </td>
                </tr>
                </tbody>
            </table>
            <div class="row">
                <div class="col-md-6 col-sm-6">
                    <div class="form-row">
                        <label class="lebel-abs">
                            Your Name
                            <strong class="red">
                                *
                            </strong>
                        </label>
                        <input type="text" name="" class="input namefild">
                    </div>
                    <div class="form-row">
                        <label class="lebel-abs">
                            Your Email
                            <strong class="red">
                                *
                            </strong>
                        </label>
                        <input type="email" name="" class="input emailfild">
                    </div>
                    <div class="form-row">
                        <label class="lebel-abs">
                            Summary of You Review
                            <strong class="red">
                                *
                            </strong>
                        </label>
                        <input type="text" name="" class="input summeryfild">
                    </div>
                </div>
                <div class="col-md-6 col-sm-6">
                    <div class="form-row">
                        <label class="lebel-abs">
                            Your Name
                            <strong class="red">
                                *
                            </strong>
                        </label>
                        <textarea class="input textareafild" name="" rows="7" >
                        </textarea>
                    </div>
                    <div class="form-row">
                        <input type="submit" value="Submit" class="button">
                    </div>
                </div>
            </div>
        </form>
    </div>
    <div class="tab-content" >
        <div class="review">
            <p class="rating">
                <i class="fa fa-star light-red">
                </i>
                <i class="fa fa-star light-red">
                </i>
                <i class="fa fa-star light-red">
                </i>
                <i class="fa fa-star-half-o gray">
                </i>
                <i class="fa fa-star-o gray">
                </i>
            </p>
            <h5 class="reviewer">
                Reviewer name
            </h5>
            <p class="review-date">
                Date: 01-01-2014
            </p>
            <p>
                Lorem ipsum dolor sit amet, consectetur adipiscing elit. Integer a eros neque. In sapien est, malesuada non interdum id, cursus vel neque.
            </p>
        </div>
        <div class="review">
            <p class="rating">
                <i class="fa fa-star light-red">
                </i>
                <i class="fa fa-star light-red">
                </i>
                <i class="fa fa-star light-red">
                </i>
                <i class="fa fa-star-half-o gray">
                </i>
                <i class="fa fa-star-o gray">
                </i>
            </p>
            <h5 class="reviewer">
                Reviewer name
            </h5>
            <p class="review-date">
                Date: 01-01-2014
            </p>
            <p>
                Lorem ipsum dolor sit amet, consectetur adipiscing elit. Integer a eros neque. In sapien est, malesuada non interdum id, cursus vel neque.
            </p>
        </div>
    </div>
</div>
</div>
<div class="clearfix">
</div>
</div>
<div class="clearfix">
</div>
</div>